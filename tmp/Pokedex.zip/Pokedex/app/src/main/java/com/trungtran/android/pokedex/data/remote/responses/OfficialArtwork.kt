package com.trungtran.android.pokedex.data.remote.responses

data class OfficialArtwork(
    val front_default: String
)
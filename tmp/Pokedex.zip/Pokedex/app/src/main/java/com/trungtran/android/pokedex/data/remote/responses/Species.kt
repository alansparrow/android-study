package com.trungtran.android.pokedex.data.remote.responses

data class Species(
    val name: String,
    val url: String
)
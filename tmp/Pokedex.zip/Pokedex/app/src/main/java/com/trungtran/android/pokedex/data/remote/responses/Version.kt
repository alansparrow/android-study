package com.trungtran.android.pokedex.data.remote.responses

data class Version(
    val name: String,
    val url: String
)
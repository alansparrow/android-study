package com.trungtran.android.pokedex.data.remote.responses

data class IconsX(
    val front_default: String,
    val front_female: String
)
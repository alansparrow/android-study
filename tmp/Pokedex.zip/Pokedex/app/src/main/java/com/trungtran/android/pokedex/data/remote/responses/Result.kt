package com.trungtran.android.pokedex.data.remote.responses

data class Result(
    val name: String,
    val url: String
)
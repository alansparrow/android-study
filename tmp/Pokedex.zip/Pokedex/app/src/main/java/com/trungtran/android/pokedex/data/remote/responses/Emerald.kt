package com.trungtran.android.pokedex.data.remote.responses

data class Emerald(
    val front_default: String,
    val front_shiny: String
)
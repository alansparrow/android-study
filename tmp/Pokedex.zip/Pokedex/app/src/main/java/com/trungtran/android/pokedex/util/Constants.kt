package com.trungtran.android.pokedex.util

object Constants {
    const val BASE_URL = "https://pokeapi.co/api/v2"
}
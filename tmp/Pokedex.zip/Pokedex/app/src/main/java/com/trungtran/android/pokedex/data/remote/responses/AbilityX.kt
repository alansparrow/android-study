package com.trungtran.android.pokedex.data.remote.responses

data class AbilityX(
    val name: String,
    val url: String
)
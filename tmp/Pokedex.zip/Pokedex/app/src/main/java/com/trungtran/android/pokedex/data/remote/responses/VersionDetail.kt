package com.trungtran.android.pokedex.data.remote.responses

data class VersionDetail(
    val rarity: Int,
    val version: Version
)
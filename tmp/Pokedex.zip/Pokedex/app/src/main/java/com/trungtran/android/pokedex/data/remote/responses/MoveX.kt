package com.trungtran.android.pokedex.data.remote.responses

data class MoveX(
    val name: String,
    val url: String
)
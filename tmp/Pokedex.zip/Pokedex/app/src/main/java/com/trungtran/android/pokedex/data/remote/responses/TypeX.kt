package com.trungtran.android.pokedex.data.remote.responses

data class TypeX(
    val name: String,
    val url: String
)